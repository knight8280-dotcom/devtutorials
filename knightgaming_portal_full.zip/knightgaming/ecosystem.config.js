/**
 * PM2 Ecosystem Configuration
 * For production deployment with PM2
 */

module.exports = {
  apps: [
    {
      name: 'knightgaming-api',
      script: './backend/server.js',
      instances: 'max',
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production',
        PORT: 3000
      },
      error_file: './logs/pm2-error.log',
      out_file: './logs/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      max_memory_restart: '500M',
      watch: false,
      ignore_watch: ['node_modules', 'logs'],
    },
    {
      name: 'worker-player-counts',
      script: './backend/workers/updatePlayerCounts.js',
      cron_restart: '*/1 * * * *', // Every minute
      autorestart: false,
      env: {
        NODE_ENV: 'production'
      }
    },
    {
      name: 'worker-games',
      script: './backend/workers/updateGames.js',
      cron_restart: '0 2 * * *', // Daily at 2 AM
      autorestart: false,
      env: {
        NODE_ENV: 'production'
      }
    },
    {
      name: 'worker-news',
      script: './backend/workers/updateNews.js',
      cron_restart: '*/15 * * * *', // Every 15 minutes
      autorestart: false,
      env: {
        NODE_ENV: 'production'
      }
    },
    {
      name: 'worker-reviews',
      script: './backend/workers/updateReviews.js',
      cron_restart: '0 3 * * *', // Daily at 3 AM
      autorestart: false,
      env: {
        NODE_ENV: 'production'
      }
    }
  ]
};
